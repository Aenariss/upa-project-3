python3 ./getUrls.py
python3 ./getProducts.py --limit 20 <urls.txt