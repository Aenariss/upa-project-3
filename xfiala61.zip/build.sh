python3 -m venv .
source ./bin/activate
chmod +x run.sh
pip install bs4
pip install cloudscraper

